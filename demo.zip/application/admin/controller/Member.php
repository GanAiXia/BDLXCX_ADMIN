<?php
/**
 * Created by PhpStorm.
 * User: GAX
 * Date: 2018-09-13 10:35
 * 网络部-程序小组
 */

namespace app\admin\controller;
use app\admin\common\Base;
use app\admin\model\Member as MemberModel;

class Member extends Base
{
    public function index()
    {

    }

    public function memberList()
    {
        $userInfo = MemberModel::all();
//        halt($userInfo);
        $this->assign('userinfo',$userInfo);
        $this->assign('title','会员列表页');
        return $this->fetch('memberlist');
    }
}